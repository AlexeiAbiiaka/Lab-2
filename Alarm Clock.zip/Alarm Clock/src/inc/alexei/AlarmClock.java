package inc.alexei;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JLabel;
import javax.swing.Timer;

import org.joda.time.Duration;
import org.joda.time.format.PeriodFormatter;
import org.joda.time.format.PeriodFormatterBuilder;

public class AlarmClock implements ActionListener 
{
	private JLabel clockLabel;
	private SimpleDateFormat sdf;
	private Timer timer;
	private Thread alarm;
	private Clip clip;
	private Date alarmAt;
	private String fileName;
	private String name;

	public AlarmClock(String name) {
		this(name, null, "HH:mm:ss");
	}
	public AlarmClock(String name, Integer alarmInSec) {
		this(name, alarmInSec, "HH:mm:ss");
	}
	public AlarmClock(String name, Integer alarmInSec, String format) {
		this(name, alarmInSec, format, "siren.wav");
	}
	
	/**
	 * 
	 * @param name - Name of alarm clock
	 * @param alarmInSec - makes alarm have seconds
	 * @param format - string format
	 * @param fileName - input name of file
	 */
	public AlarmClock(String name, Integer alarmInSec, String format, String fileName) {
		setName(name);
		setFormat(format);
		if (alarmInSec!=null) {
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.SECOND, alarmInSec);
			setAlarmAt(cal.getTime());
		}
		setAlarmAt(alarmAt);
		setFileName(fileName);
	}

	public void setFormat(String format) {
		sdf = new SimpleDateFormat(format);
	}
	
	/**
	 * 
	 * @param str - makes hours, minutes, seconds on clock
	 */
	public void setAlarmAt(String str) {
		try {
			alarmAt = sdf.parse(str);
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.HOUR_OF_DAY, alarmAt.getHours());
			cal.set(Calendar.MINUTE, alarmAt.getMinutes());
			cal.set(Calendar.SECOND, alarmAt.getSeconds());
			alarmAt = cal.getTime();
		} catch (Exception e) {}
	}
	public Date getAlarmAt() {
		return alarmAt;
	}
	public void setAlarmAt(Date alarmAt) {
		this.alarmAt = alarmAt;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
	/**
	 * 
	 * @return - text of numbers
	 */
	public JLabel getClock() {
		if (clockLabel==null) {
	
			clockLabel = new JLabel();
			clockLabel.setText(sdf.format(new Date()));
			clockLabel.setFont(new Font("Dialog", Font.PLAIN, 24));

			timer = new Timer(500, this);
			timer.setRepeats(true);
			timer.start();
		}
		return clockLabel;
	}
	
	public void actionPerformed(ActionEvent e) {
		// If the timer caused this event.
		if (e.getSource().equals(timer)) {
			// Then set a new time.
			Date now = new Date();
			if (alarm==null && alarmAt!=null && now.after(alarmAt)) {
				playAlarm();
			}
			StringBuilder sb = new StringBuilder();
			if (name!=null) {
				sb.append(name).append(": ");
			}
			sb.append(sdf.format(now));
			if (alarmAt!=null) {
				if (alarm!=null) {
					sb.append(" alarm is on");
					Duration duration = new Duration(now.getTime() - alarmAt.getTime());
					if (duration.getStandardSeconds()>=5)
						stopAlarm();
				} else {
					Duration duration = new Duration(alarmAt.getTime() - now.getTime()); // in milliseconds
					PeriodFormatter formatter = new PeriodFormatterBuilder()
						.printZeroAlways()
						.minimumPrintedDigits(2)
						.appendHours()
						.appendSuffix(":")
						.appendMinutes()
						.appendSuffix(":")
						.appendSeconds()
						.toFormatter();
					String formatted = formatter.print(duration.toPeriod());
					sb.append(" alarm will start in ").append(formatted);
				}
			} else if (alarmAt==null && alarm!=null) {
				sb.append(" alarm is off");
			}
			clockLabel.setText(sb.toString());
		}
	}
	
	public synchronized void playAlarm() {
		if (alarm==null) {
			alarm = new Thread(new Runnable() {
				public void run() {
					try {
						clip = AudioSystem.getClip();
						AudioInputStream inputStream = AudioSystem
								.getAudioInputStream(AlarmClock.class.getResourceAsStream(fileName));
						clip.open(inputStream);
						clip.start();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
			alarm.start();
		}
	}
	
	public void stop() {
		stopTimer();
		stopAlarm();
	}
	public void stopTimer() {
		try {
			if (timer!=null)
				timer.stop();
		} catch (Exception e) {}
	}
	public void stopAlarm() {
		try {
			alarmAt = null;
			if (clip!=null)
				clip.stop();
			if (alarm!=null)
				alarm.interrupt();
		} catch (Exception e) {}
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
