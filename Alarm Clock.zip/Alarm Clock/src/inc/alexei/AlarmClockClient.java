package inc.alexei;

import javax.swing.JLabel;

public class AlarmClockClient {

	public static void main(String[] args) {
		Banner banner = new Banner("Alarm Clock");
		AlarmClock[] alarmClocks = new AlarmClock[] {
				new AlarmClock("Alarm 1", 5),
				new AlarmClock("Alarm 2", 15),
				new AlarmClock("Alarm 3", 25)
		};
		JLabel[] labels = new JLabel[] {
				alarmClocks[0].getClock(),
				alarmClocks[1].getClock(),
				alarmClocks[2].getClock()
		};
		banner.printBanner(labels);
		alarmClocks[0].stop();
		alarmClocks[1].stop();
		alarmClocks[2].stop();
	}

}
