package inc.alexei;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class Banner {
	private String assignment;
	
	/**
	 * @param assignment - name of class
	 */
	public Banner(String assignment) {
		this.assignment = assignment;
	}
	
	/**
	 * @param message - option message can be added to the banner. Ex. description of project
	 * @return - format of banner
	 */
	private String getBanner(String message) {
		int len = 20;
		if ("Assignment: ".length()+assignment.length() > 20)
			len = "Assignment: ".length()+assignment.length();
		if (message!=null && message.length()>len)
			len = message.length();
		StringBuilder sb = new StringBuilder();
		formatString(sb, '*', len);
		formatString(sb, "Name: ", "Alexei Abiiaka", ' ', len);
		formatString(sb, "Class: ", "CS 30S", ' ', len);
		formatString(sb, "Assignment:  ", assignment, ' ', len);
		if (message!=null) {
			formatString(sb, message, null, ' ', len);
		}
		formatString(sb, '*', len);
		return sb.toString();
	}// end getBanner
	
	/**
	 * entire line filled with stars of spaces
	 * @param sb - stringBuilder combines message lines
	 * @param filler - character to fill in blank space
	 * @param size - max characters in a line
	 */
	private void formatString(StringBuilder sb, char filler, int size) {
		formatString(sb, null, null, filler, size);
	}// end formatString
	
	/**
	 * aligning columns in the banner
	 * @param sb - stringBuilder combines message lines
	 * @param prefix - left side of message
	 * @param suffix - right side of message
	 * @param filler - spaces between prefix and suffix
	 * @param size - max size of message line
	 */
	private void formatString(StringBuilder sb, String prefix, String suffix, char filler, int size) {
		int strlen = 0;
		if (prefix!=null) {
			sb.append(prefix);
			strlen+=prefix.length();
		}
		if (suffix!=null)
			strlen+=suffix.length();
		
		if (strlen<size) {
			for (int i=0; i<size-strlen; i++) {
				sb.append(filler);
			}
		}
		
		if (suffix!=null)
			sb.append(suffix);
		sb.append("\n");
	}// end formatString
	
	/**
	 * Prints a banner, default banner without message
	 */
	public void printBanner() {
		outputDialog( getBanner(null) );
	}//end printBanner
	
	/**
	 * 
	 * @param message - print this message
	 */
	public void printBanner(String message) {
		outputDialog( getBanner(message) );
	}// end printBanner
	
	public void printBanner(JLabel[] labels) {
		outputDialog( getBanner(null), labels );
	}//end printBanner
	
	/**
	 * displays dialog for string input
	 * @param message - print this message
	 * @return - entered string
	 */
	public String inputString(String message) {
		return inputDialog( getBanner(message) );
	}// end printBanner

	public String inputString(String message, JLabel[] labels) {
		return inputDialog( getBanner(message), labels );
	}//end printBanner
	
	private JPanel getPanel(String str, JLabel[] labels) {
		JPanel panel = new JPanel(new GridLayout(0,1));
		String[] lines = str.split("\n");
		for (String line: lines) {
			JLabel label = new JLabel( line );
			label.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
			panel.add(label);
		}
		if (labels!=null) {
			for (JLabel label: labels) {
				panel.add(label);
			}
		}
		return panel;
	}
	
	private void outputDialog(String str) {// start outputWindow
		outputDialog(str, null);
	}// end outputWindow
	/**
	 * JLabel is using html format so i have to replace spaces to non-breakable spaces, and new line character to br tag
	 * making font monospaced for text in JOption
	 * @param str - outputs banner with entered message
	 */
	private void outputDialog(String str, JLabel[] labels) {// start outputWindow
		System.out.println(str);
		ImageIcon icon = new ImageIcon(this.getClass().getResource("cube.gif"));
		JOptionPane.showMessageDialog(null, getPanel(str, labels), "Message Dialog", JOptionPane.INFORMATION_MESSAGE, icon);
	}// end outputWindow
	
	private String inputDialog(String str) {
		return inputDialog(str, null);
	}// end inputWindow
	/**
	 * JLabel is using html format so i have to replace spaces to non-breakable spaces, and new line character to br tag.
	 * making font monospaced for text in JOption and reading new written string
	 * @param str - suggestion for input string
	 * @return - entered string
	 */
	private String inputDialog(String str, JLabel[] labels) {// start inputWindow
		System.out.println(str);
		ImageIcon icon = new ImageIcon(this.getClass().getResource("cube.gif"));
		str = (String) JOptionPane.showInputDialog(null, getPanel(str, labels), "Input Dialog", JOptionPane.QUESTION_MESSAGE, icon, null, null);
		System.out.println("We entered: "+str);
		return str;
	}// end inputWindow
	
	public void endOfProcessing() {
		outputDialog ("End Of Processing");
	}// end endOfProcessing
	
}